package com.hcl.sfh.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.sfh.entities.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long>{

}
