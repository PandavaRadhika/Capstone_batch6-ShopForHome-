package com.hcl.sfh.vo;

import com.hcl.sfh.dto.Discount;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@Setter
@ToString

public class DiscountVo {

	private Discount discount;
}
