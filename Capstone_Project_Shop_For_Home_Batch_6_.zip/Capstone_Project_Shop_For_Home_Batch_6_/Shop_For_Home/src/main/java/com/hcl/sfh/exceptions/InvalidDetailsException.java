package com.hcl.sfh.exceptions;

public class InvalidDetailsException extends Exception {

}
