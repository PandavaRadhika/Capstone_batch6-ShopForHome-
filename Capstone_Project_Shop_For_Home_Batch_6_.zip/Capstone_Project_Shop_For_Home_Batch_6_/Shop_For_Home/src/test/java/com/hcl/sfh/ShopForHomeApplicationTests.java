package com.hcl.sfh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopForHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
