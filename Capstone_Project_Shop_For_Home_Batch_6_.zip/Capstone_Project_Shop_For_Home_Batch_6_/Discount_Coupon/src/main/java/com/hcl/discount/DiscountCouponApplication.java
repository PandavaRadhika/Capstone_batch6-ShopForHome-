package com.hcl.discount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscountCouponApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscountCouponApplication.class, args);
	}

}
