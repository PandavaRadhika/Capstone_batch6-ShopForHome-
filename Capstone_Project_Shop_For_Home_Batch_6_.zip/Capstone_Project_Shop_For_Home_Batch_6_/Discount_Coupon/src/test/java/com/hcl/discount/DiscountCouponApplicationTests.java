package com.hcl.discount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscountCouponApplicationTests {

	@Test
	void contextLoads() {
	}

}
