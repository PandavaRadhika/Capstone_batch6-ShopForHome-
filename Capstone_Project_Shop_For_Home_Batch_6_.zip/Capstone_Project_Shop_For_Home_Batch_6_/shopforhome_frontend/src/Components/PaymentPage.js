import React from 'react'
import GetDiscountByCouponName from './GetDiscountByCouponName'

function PaymentPage() {

  return (
      <>
      <h1>Welcome to Payment Page</h1>

      <GetDiscountByCouponName></GetDiscountByCouponName>
      
      </>
          
  )
}

export default PaymentPage