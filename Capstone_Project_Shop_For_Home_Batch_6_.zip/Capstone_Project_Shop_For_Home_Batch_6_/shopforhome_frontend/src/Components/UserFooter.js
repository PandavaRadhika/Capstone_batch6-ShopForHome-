import React from 'react'

function UserFooter() {
  return (
    <div style={{backgroundColor:"aqua" ,textAlign:"center"}}>
        <h6>@Copyright 2023 </h6>
     
        <h6>Help  ph:+91777339801 ::  shopforhome@gmail.com</h6>
    </div>
  );
}

export default UserFooter